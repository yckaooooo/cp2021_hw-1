from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import ctypes
 
lib = ctypes.CDLL('./multiply2.dll')
# By default functions are assumed to return the C int type. Other return types can be specified by setting the restype attribute of the function object.
lib.multiply.restype = ctypes.c_float
#result = lib.multiply(ctypes.c_float(3.0), ctypes.c_float(2.0))
#print(result)
 
# Initialize the Flask application
app = Flask(__name__)
CORS(app, support_credentials=False)
 
@app.route('/')
def index():
    #return render_template('index.html')
    return "index"
 
@app.route('/add_numbers', methods=['POST'])
def add_numbers():
    #a = request.form.get('a', 0, type=int)
    #b = request.form.get('b', 0, type=int)
    a = request.form.get('a')
    b = request.form.get('b')
    result = lib.multiply(ctypes.c_float(float(a)), ctypes.c_float(float(b)))
    #return jsonify(result = a+b)
    # 必須傳回字串?
    #return str(a+b)
    return str(result)
 
if __name__ == '__main__':
    app.run(debug=True, port=9448) #, ssl_context="adhoc")